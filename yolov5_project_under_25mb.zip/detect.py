import torch
import cv2
import argparse
import os

# Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument('--source', type=str, default='images/bus.jpg', help='Image or video path')
parser.add_argument('--weights', type=str, default='yolov5s.pt', help='YOLOv5 weights')
parser.add_argument('--output', type=str, default='result.mp4', help='Output video file name')
args = parser.parse_args()

# Load model
model = torch.hub.load('ultralytics/yolov5', 'custom', path=args.weights)

# Check source
source = args.source
if not os.path.exists(source):
    raise FileNotFoundError(f"Source file '{source}' not found")

# Video or image
if source.endswith(('.mp4', '.avi')):
    cap = cv2.VideoCapture(source)

    # Setup video writer
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS) or 20.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    out = cv2.VideoWriter(args.output, fourcc, fps, (width, height))

    print(f"Processing video ({total_frames} frames)... Saving to: {args.output}")
    frame_count = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            print("End of video reached or frame read failed.")
            break

        # Inference
        results = model(frame)
        results.render()

        # Save frame
        out.write(results.ims[0])

        frame_count += 1
        if frame_count % 10 == 0:
            print(f"Processed {frame_count}/{total_frames} frames...")

    cap.release()
    out.release()
    print(f"Done! Video saved as '{args.output}'")

else:
    # Process image
    img = cv2.imread(source)
    results = model(img)
    results.render()

    output_path = 'runs/detect/exp'
    os.makedirs(output_path, exist_ok=True)
    output_file = os.path.join(output_path, os.path.basename(source))
    cv2.imwrite(output_file, results.ims[0])
    print(f"Image processed. Results saved to {output_file}")
